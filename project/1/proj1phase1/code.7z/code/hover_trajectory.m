function s_des = hover_trajectory(t, true_s)

    s_des = zeros(13,1);
    s_des(7:10) = [1;0;0;0];

end
